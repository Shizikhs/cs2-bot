# CS2 Bot

Телеграм-бот для сбора заявок от победителей розыгрышей.

## Как запустить

1. Создай `.env` файл:
```
BOT_TOKEN=your_token
```

2. Установи зависимости:
```
pip install -r requirements.txt
```

3. Запусти бота:
```
python bot.py
```
